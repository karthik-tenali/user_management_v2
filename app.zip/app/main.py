from fastapi import FastAPI
from app.db.session import Base, engine
from app.api.users import router as users_router
from app.api.auth import router as auth_router


app = FastAPI()
app.include_router(auth_router)
app.include_router(users_router)

Base.metadata.create_all(bind=engine)

